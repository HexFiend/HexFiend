//
//  HFRepresenterTextLayoutManager.m
//  HexFiend_2
//
//  Created by Peter Ammon on 11/10/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "HFRepresenterTextLayoutManager.h"


@implementation HFRepresenterTextLayoutManager

@end
