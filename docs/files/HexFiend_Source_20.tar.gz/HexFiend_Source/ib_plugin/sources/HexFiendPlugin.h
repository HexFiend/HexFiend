#import <InterfaceBuilderKit/InterfaceBuilderKit.h>


@interface HexFiendPlugin : IBPlugin {

}

@end
