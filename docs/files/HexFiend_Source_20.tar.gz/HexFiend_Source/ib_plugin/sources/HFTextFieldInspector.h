//
//  HFTextFieldInspector.h
//  HexFiend_2
//
//  Created by Peter Ammon on 2/6/08.
//  Copyright 2008 ridiculous_fish. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface HFTextFieldInspector : IBInspector {
}
@end
