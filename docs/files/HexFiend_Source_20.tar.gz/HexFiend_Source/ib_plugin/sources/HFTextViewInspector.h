//
//  HFTextViewInspector.h
//  HexFiend_2
//
//  Created by Peter Ammon on 6/29/09.
//  Copyright 2009 ridiculous_fish. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface HFTextViewInspector : IBInspector {
}
@end
