//
//  main.m
//  HexFiendling
//
//  Created by Peter Ammon on 6/22/09.
//  Copyright ridiculous_fish 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
