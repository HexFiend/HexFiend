//
//  HFBannerDividerThumb.h
//  HexFiend_2
//
//  Created by Peter Ammon on 1/29/08.
//  Copyright 2008 ridiculous_fish. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HFBannerDividerThumb : NSView {

}

@end
