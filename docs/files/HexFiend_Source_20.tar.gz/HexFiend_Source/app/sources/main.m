//
//  main.m
//  HexFiend_2
//
//  Created by Peter Ammon on 11/2/07.
//  Copyright ridiculous_fish 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
