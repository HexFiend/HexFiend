//
//  HFRepresenterTextLayoutManager.h
//  HexFiend_2
//
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HFRepresenterTextLayoutManager : NSLayoutManager {

}

@end
