//
//  HFRepresenterTextLayoutManager.m
//  HexFiend_2
//
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "HFRepresenterTextLayoutManager.h"


@implementation HFRepresenterTextLayoutManager

@end
