Hex Fiend is a fast and clever hex editor for Mac OS X, written using the Cocoa frameworks. Hex Fiend also provides a framework, allowing "hex views" to be embedded in other applications.

Hex Fiend is released under a liberal BSD-style license.

For more information about Hex Fiend, see http://ridiculousfish.com/hexfiend/

