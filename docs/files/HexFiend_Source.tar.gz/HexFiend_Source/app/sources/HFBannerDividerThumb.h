//
//  HFBannerDividerThumb.h
//  HexFiend_2
//
//  Copyright 2008 ridiculous_fish. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HFBannerDividerThumb : NSView {

}

@end
