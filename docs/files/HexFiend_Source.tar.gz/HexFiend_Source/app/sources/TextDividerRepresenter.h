//
//  TextDividerRepresenter.h
//  HexFiend_2
//
//  Copyright 2011 ridiculous_fish. All rights reserved.
//

#import <HexFiend/HFRepresenter.h>

@interface TextDividerRepresenter : HFRepresenter

@end
