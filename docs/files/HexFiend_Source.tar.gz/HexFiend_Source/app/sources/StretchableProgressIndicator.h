//
//  StretchableProgressIndicator.h
//  HexFiend_2
//
//  Copyright 2010 ridiculous_fish. All rights reserved.
//

#import <AppKit/NSView.h>


@interface StretchableProgressIndicator : NSProgressIndicator {
    id gradient;
}

@end
