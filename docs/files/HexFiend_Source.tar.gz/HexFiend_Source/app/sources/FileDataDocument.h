//
//  FileDataDocument.h
//  HexFiend_2
//
//  Copyright 2009 ridiculous_fish. All rights reserved.
//

#import "BaseDataDocument.h"

@interface FileDataDocument : BaseDataDocument {

}

@end
