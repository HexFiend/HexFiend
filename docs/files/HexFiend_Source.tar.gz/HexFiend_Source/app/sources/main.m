//
//  main.m
//  HexFiend_2
//
//  Copyright ridiculous_fish 2007. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
