<?php if (!defined('PmWiki')) exit();
## Use "Clean URLs".
$EnablePathInfo = 1;
$ScriptUrl = dirname($_SERVER['SCRIPT_NAME']);
## more configuration settings...

$DefaultPasswords['admin'] = crypt('ivanmicrobe13');
$DefaultPasswords['edit'] = crypt('hexfiend');

$EnableNotify = 1;

